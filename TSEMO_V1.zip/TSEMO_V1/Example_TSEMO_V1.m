%% Example on how to use TSEMO_V1

%% Step 1: Create function file with multiobjective function to be optimized
% In this example we aim to find the Pareto front of "kno1", e.g. see kno1
% for format

f = @kno1; % example function in the folder "Test_functions"

%% Step 2 Set path to folder
% Matlab Home, Set Path, Add folder with subfolders, select "TS-EMO_V1"
% folder

%% Step 3: Specify problem
no_outputs = 2;               % number of objectives
no_inputs = 2;                % number of decision variables
lb = zeros(1,2);              % define lower bound on decision variables, [lb1,lb2,...]
ub = 3*ones(1,2);             % define upper bound on decision variables, [ub1,ub2,...]
dataset_size = 5*no_inputs;   % initial dataset size      

%% Step 4: Generate initial dataset
X = lhsdesign(dataset_size,no_inputs);  % Latin hypercube design
Y = zeros(dataset_size,no_outputs);     % corresponding matrix of response data
for k = 1:size(X,1)
    X(k,:) = X(k,:).*(ub-lb)+lb;        % adjustment of bounds
    Y(k,:) = f(X(k,:));                 % calculation of response data
end

opt = TSEMO_V1_opt;              % call options for solver, see TSEMO_V1_opt file to adjust
opt.maxeval = 50;                % number of function evaluations before termination
opt.NoOfBachSequential = 1;      % number of function evaluations per iteration
% Total number of iterations = opt.maxeval/opt.NoOfBachSequential

%% Step 5: Start algorithm to find Pareto front
[Xpareto,Ypareto,X,Y] = TSEMO_V1(f,X,Y,lb,ub,opt);

% Xpareto and Ypareto correspond to the current best Pareto set and Pareto
% front respectively. 
% X and Y are the complete dataset of the decision variables and 
% the objectives respectively. 

% For each iteration the current iteration number is displayed, the
% predicted hypervolume improvement and the time taken

%% Step 6: Visualise results
figure
hold on
plot(Y(1:dataset_size,1),Y(1:dataset_size,2),'.','MarkerSize',14)
plot(Y(dataset_size+1:end,1),Y(dataset_size+1:end,2),'x','MarkerSize',8,'LineWidth',2)
plot(Ypareto(:,1),Ypareto(:,2),'O','MarkerSize',8,'LineWidth',2)
legend('Initial LHC','Algorithm','Pareto set','Location','Northeast')
title('Results TS-EMO algorithm')
xlabel('f_1')
ylabel('f_2')