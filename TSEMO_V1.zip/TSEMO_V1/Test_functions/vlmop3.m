function f = vlmop3 ( x )
% vlmop3 : Multi-Objective Problem no. 3

f(:,1) = 0.5*(x(1)^2 + x(2)^2) + sin(x(1)^2+x(2)^2);
f(:,2) = ((3*x(1) - 2*x(2) + 4)^2)/8 + ((x(1)-x(2)+1)^2)/27 + 15;
f(:,3) = 1/(x(1)^2 + x(2)^2 + 1) - 1.1*exp(-x(1)^2-x(2)^2);
