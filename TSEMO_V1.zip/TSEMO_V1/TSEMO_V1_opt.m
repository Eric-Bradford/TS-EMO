function opt = TSEMO_opt

% Description: Create TS-EMO options structure.             
opt.maxeval = 35;                   % Maximum number of funciton evaluations

for i = 1:3  
opt.GP(i).nSpectralpoints = 4000;   % Number of spectral sampling points
opt.GP(i).matern = 1;               % Matern type 1 / 3 / 5 / inf
opt.GP(i).fun_eval = 200;           % Function evaluations by direct algorithm per input dimension
end

opt.pop = 100;                      % Genetic algorithm population size
opt.Generation = 100;               % Genetic algorithm number of generations    
opt.NoOfBachSequential = 1;         % Batch size 
end